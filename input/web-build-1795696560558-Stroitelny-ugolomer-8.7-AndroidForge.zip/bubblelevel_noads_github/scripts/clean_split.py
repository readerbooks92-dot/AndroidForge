#!/usr/bin/env python3
"""Copy a split APK while removing old JAR/BUNDLE signatures before re-signing."""
from __future__ import annotations

from pathlib import Path
import sys
import zipfile

if len(sys.argv) != 3:
    raise SystemExit("usage: clean_split.py input.apk output.apk")

src, dst = map(Path, sys.argv[1:])
dst.parent.mkdir(parents=True, exist_ok=True)

with zipfile.ZipFile(src, "r") as zin, zipfile.ZipFile(dst, "w") as zout:
    for info in zin.infolist():
        name = info.filename
        upper = name.upper()
        if upper.startswith("META-INF/"):
            continue
        if name == "stamp-cert-sha256":
            continue
        data = zin.read(name)
        # Preserve the entry metadata that matters, but don't carry through
        # old signing metadata after the APK content is re-signed.
        new_info = zipfile.ZipInfo(name, date_time=info.date_time)
        new_info.compress_type = info.compress_type
        new_info.external_attr = info.external_attr
        new_info.internal_attr = info.internal_attr
        new_info.extra = info.extra
        zout.writestr(new_info, data)

print(f"Prepared {src.name} for re-signing -> {dst}")
