#!/usr/bin/env python3
"""Set the Android launcher/application label in Apktool-decoded manifest."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

if len(sys.argv) != 2:
    raise SystemExit("usage: set_app_name.py <decoded-apk-directory>")

manifest = Path(sys.argv[1]) / "AndroidManifest.xml"
if not manifest.is_file():
    raise SystemExit(f"ERROR: decoded manifest not found: {manifest}")

ANDROID = "http://schemas.android.com/apk/res/android"
ET.register_namespace("android", ANDROID)
label_attr = f"{{{ANDROID}}}label"
root = ET.parse(manifest).getroot()
application = root.find("application")
if application is None:
    raise SystemExit("ERROR: <application> element not found")

new_name = "Строительный угломер"
application.set(label_attr, new_name)
launcher_count = 0
for activity_tag in ("activity", "activity-alias"):
    for activity in application.findall(activity_tag):
        is_launcher = False
        for intent_filter in activity.findall("intent-filter"):
            actions = {node.get(f"{{{ANDROID}}}name") for node in intent_filter.findall("action")}
            categories = {node.get(f"{{{ANDROID}}}name") for node in intent_filter.findall("category")}
            if "android.intent.action.MAIN" in actions and "android.intent.category.LAUNCHER" in categories:
                is_launcher = True
                break
        if is_launcher:
            activity.set(label_attr, new_name)
            launcher_count += 1

ET.indent(root, space="    ")
ET.ElementTree(root).write(manifest, encoding="utf-8", xml_declaration=True)
print(f"Application label set to: {new_name}")
print(f"Launcher component labels updated: {launcher_count}")
