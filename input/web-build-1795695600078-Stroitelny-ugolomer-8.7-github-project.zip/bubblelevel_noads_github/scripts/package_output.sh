#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID_BUILD_TOOLS="${ANDROID_SDK_ROOT:-${ANDROID_HOME:?ANDROID_SDK_ROOT/ANDROID_HOME is required}}/build-tools/35.0.0"
OUT="$ROOT/build/output"
PREP="$ROOT/build/prepared"
mkdir -p "$OUT" "$PREP"

for tool in zipalign apksigner; do
  if [[ ! -x "$ANDROID_BUILD_TOOLS/$tool" ]]; then
    echo "ERROR: missing $ANDROID_BUILD_TOOLS/$tool" >&2
    exit 2
  fi
done

# Temporary signing identity: a modified APK cannot retain the developer's
# original signature because the original private signing key is not available.
STORE_PASS="$(openssl rand -hex 16)"
KEYSTORE="$ROOT/build/local-signing.jks"
keytool -genkeypair -v \
  -keystore "$KEYSTORE" \
  -storepass "$STORE_PASS" \
  -keypass "$STORE_PASS" \
  -alias bubblelevel-local \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=Stroitelny Ugolomer Local Modified Build, O=Personal Use" \
  -noprompt >/dev/null 2>&1

sign_one() {
  local input="$1"
  local output="$2"
  local aligned="$PREP/$(basename "$output").aligned.apk"
  "$ANDROID_BUILD_TOOLS/zipalign" -f -p 4 "$input" "$aligned"
  "$ANDROID_BUILD_TOOLS/apksigner" sign \
    --ks "$KEYSTORE" \
    --ks-key-alias bubblelevel-local \
    --ks-pass "pass:$STORE_PASS" \
    --key-pass "pass:$STORE_PASS" \
    --out "$output" "$aligned"
  "$ANDROID_BUILD_TOOLS/apksigner" verify --verbose "$output" >/dev/null
}

sign_one "$ROOT/build/base-unsigned.apk" "$OUT/base.apk"

for split in split_config.arm64_v8a split_config.ru split_config.xxhdpi; do
  python3 "$ROOT/scripts/clean_split.py" \
    "$ROOT/input/$split.apk" "$PREP/$split.prepared.apk"
  sign_one "$PREP/$split.prepared.apk" "$OUT/$split.apk"
done

cat > "$OUT/INSTALL.txt" <<'TXT'
Строительный угломер 8.7-release — locally modified split APK set

The four APK files in this folder are one installation set. Install them
TOGETHER with Android Debug Bridge:

  adb install-multiple -r base.apk split_config.arm64_v8a.apk split_config.ru.apk split_config.xxhdpi.apk

The modified APK is signed with a new local certificate. It cannot update the
Play Store copy in place. Uninstall the official app first, then install this
set. Uninstalling may erase the app's local data/settings; export or record
calibration/preferences first where possible.

This patch disables the single app-side Yandex interstitial load request found
in the supplied 8.7-release package. Ad SDK libraries remain bundled. This is
not a guarantee that every possible promotional/ad surface is removed.
TXT

cp "$ROOT/build/decoded/PATCH_REPORT.txt" "$OUT/PATCH_REPORT.txt"
(
  cd "$OUT"
  zip -q -9 "$ROOT/build/Stroitelny_ugolomer_8.7_noads_APK_set.zip" \
    base.apk split_config.arm64_v8a.apk split_config.ru.apk split_config.xxhdpi.apk \
    INSTALL.txt PATCH_REPORT.txt
)
echo "Created: $ROOT/build/Stroitelny_ugolomer_8.7_noads_APK_set.zip"
