#!/usr/bin/env python3
"""Disable the app-owned Yandex interstitial load request in this exact build.

The script intentionally patches only the single call site identified in
org.nixgame.bubblelevel 8.7-release. It does not delete ad SDK libraries,
which could break unrelated runtime components.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
DECODED = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "build" / "decoded"

# Exact DEX method reference seen in the supplied 8.7-release classes2.dex.
TARGET = (
    "Lcom/yandex/mobile/ads/interstitial/InterstitialAdLoader;->loadAd("
    "Lcom/yandex/mobile/ads/common/AdRequest;"
    "Lcom/yandex/mobile/ads/interstitial/InterstitialAdLoadListener;)V"
)
EXPECTED_COUNT = 1


def main() -> int:
    if not DECODED.is_dir():
        print(f"ERROR: decoded APK directory not found: {DECODED}", file=sys.stderr)
        return 2

    # Limit patching to the app's own package, never the ad SDK implementation.
    candidates = []
    for smali_dir in DECODED.glob("smali*"):
        app_dir = smali_dir / "org" / "nixgame"
        if app_dir.is_dir():
            candidates.extend(app_dir.rglob("*.smali"))

    hits: list[tuple[Path, int, str]] = []
    for path in candidates:
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError as exc:
            print(f"ERROR: cannot decode {path}: {exc}", file=sys.stderr)
            return 2
        for number, line in enumerate(lines, start=1):
            if TARGET in line:
                if not re.match(r"^\s*invoke-[a-z-]+(?:/range)?\s+\{", line):
                    print(f"ERROR: target reference is not an invoke instruction at {path}:{number}", file=sys.stderr)
                    return 2
                hits.append((path, number, line))

    if len(hits) != EXPECTED_COUNT:
        print(
            f"ERROR: expected exactly {EXPECTED_COUNT} app-side interstitial load call, "
            f"found {len(hits)}. Refusing to produce an unverified build.",
            file=sys.stderr,
        )
        for path, number, line in hits:
            print(f"  {path}:{number}: {line}", file=sys.stderr)
        return 1

    # A normal invoke instruction occupies 3 DEX code units. Three NOPs retain
    # the code-item length, so existing branch offsets and try ranges stay valid.
    path, number, original = hits[0]
    lines = path.read_text(encoding="utf-8").splitlines()
    indent = re.match(r"^\s*", original).group(0)
    lines[number - 1:number] = [
        indent + "nop    # disabled app-side interstitial request",
        indent + "nop",
        indent + "nop",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    # Confirm the target call no longer exists in app-owned smali.
    remaining = []
    for smali_dir in DECODED.glob("smali*"):
        app_dir = smali_dir / "org" / "nixgame"
        if app_dir.is_dir():
            for file in app_dir.rglob("*.smali"):
                if TARGET in file.read_text(encoding="utf-8"):
                    remaining.append(file)
    if remaining:
        print("ERROR: patch verification failed; call still present", file=sys.stderr)
        return 1

    report = (
        "Patch report — Bubble Level 8.7-release\n"
        f"Disabled call: {TARGET}\n"
        f"Location: {path.relative_to(DECODED)}:{number}\n"
        "Action: replaced one 3-code-unit invoke instruction with three NOPs.\n"
        "Ad SDK libraries were retained.\n"
    )
    (DECODED / "PATCH_REPORT.txt").write_text(report, encoding="utf-8")
    print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
