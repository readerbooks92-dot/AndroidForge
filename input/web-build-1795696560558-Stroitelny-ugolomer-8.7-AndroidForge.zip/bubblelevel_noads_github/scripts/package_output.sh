#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID_BUILD_TOOLS="${ANDROID_BUILD_TOOLS:-}"
if [[ -z "$ANDROID_BUILD_TOOLS" ]]; then
  SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/opt/android-sdk}}"
  while IFS= read -r candidate; do
    if [[ -x "$candidate/apksigner" && -x "$candidate/zipalign" ]]; then
      ANDROID_BUILD_TOOLS="$candidate"
      break
    fi
  done < <(find "$SDK_ROOT/build-tools" -mindepth 2 -maxdepth 2 -type f -name apksigner -printf '%h\n' 2>/dev/null | sort -Vr)
fi
if [[ -z "$ANDROID_BUILD_TOOLS" || ! -x "$ANDROID_BUILD_TOOLS/apksigner" || ! -x "$ANDROID_BUILD_TOOLS/zipalign" ]]; then
  echo "ERROR: Android Build Tools with apksigner and zipalign were not found" >&2
  exit 2
fi

for cmd in keytool zip python3; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "ERROR: required command not found: $cmd" >&2; exit 2; }
done

OUT="$ROOT/build/outputs/apk/debug"
PREP="$ROOT/build/prepared"
SET_ZIP="$ROOT/build/Stroitelny_ugolomer_8.7_noads_APK_set.zip"
mkdir -p "$OUT" "$PREP"

for tool in zipalign apksigner; do
  [[ -x "$ANDROID_BUILD_TOOLS/$tool" ]] || { echo "ERROR: missing $ANDROID_BUILD_TOOLS/$tool" >&2; exit 2; }
done

# A modified APK cannot retain the developer's original signature because
# the original private signing key is not available in the user's export.
STORE_PASS="$(python3 -c 'import secrets; print(secrets.token_hex(16))')"
KEYSTORE="$ROOT/build/local-signing.jks"
keytool -genkeypair -v \
  -keystore "$KEYSTORE" \
  -storepass "$STORE_PASS" \
  -keypass "$STORE_PASS" \
  -alias stroitelny-ugolomer-local \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=Stroitelny Ugolomer Local Modified Build, O=Personal Use" \
  -noprompt >/dev/null 2>&1

sign_one() {
  local input="$1"
  local output="$2"
  local aligned="$PREP/$(basename "$output").aligned.apk"
  "$ANDROID_BUILD_TOOLS/zipalign" -f -p 4 "$input" "$aligned"
  "$ANDROID_BUILD_TOOLS/apksigner" sign \
    --ks "$KEYSTORE" \
    --ks-key-alias stroitelny-ugolomer-local \
    --ks-pass "pass:$STORE_PASS" \
    --key-pass "pass:$STORE_PASS" \
    --out "$output" "$aligned"
  "$ANDROID_BUILD_TOOLS/apksigner" verify --verbose "$output" >/dev/null
}

sign_one "$ROOT/build/base-unsigned.apk" "$OUT/Stroitelny-ugolomer-debug.apk"

for split in split_config.arm64_v8a split_config.ru split_config.xxhdpi; do
  python3 "$ROOT/scripts/clean_split.py" \
    "$ROOT/input/$split.apk.source" "$PREP/$split.prepared.apk"
  sign_one "$PREP/$split.prepared.apk" "$OUT/$split.apk"
done

cat > "$ROOT/build/INSTALL.txt" <<'TXT'
Строительный угломер 8.7-release — набор split APK для личной установки.

Все четыре APK являются одним комплектом. Устанавливайте их вместе через ADB:

  adb install-multiple -r Stroitelny-ugolomer-debug.apk split_config.arm64_v8a.apk split_config.ru.apk split_config.xxhdpi.apk

Новая сборка подписана локальным ключом и не сможет обновить оригинальную
версию Google Play поверх неё. Перед установкой потребуется удалить исходное
приложение. Удаление может стереть локальные настройки и калибровки.

Патч отключает один найденный запрос межстраничной рекламы Yandex в коде
приложения. Рекламные SDK оставлены; наличие других рекламных/промо-элементов
этим патчем не исключается.
TXT

cp "$ROOT/build/decoded/PATCH_REPORT.txt" "$ROOT/build/PATCH_REPORT.txt"
(
  cd "$OUT"
  zip -q -9 "$SET_ZIP" \
    Stroitelny-ugolomer-debug.apk split_config.arm64_v8a.apk split_config.ru.apk split_config.xxhdpi.apk
)

printf 'Created APK set ZIP: %s\n' "$SET_ZIP"
printf 'Individual APKs for AndroidForge collector: %s\n' "$OUT"
