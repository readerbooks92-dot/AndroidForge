#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

APKTOOL_VERSION="3.0.3"
APKTOOL_URL="https://github.com/iBotPeaches/Apktool/releases/download/v${APKTOOL_VERSION}/apktool_${APKTOOL_VERSION}.jar"
APKTOOL_SHA256="dbf930b076c6b9be08d57c449cacefc3bdd6b71ebd59b3066fc0e1f5b14f9423"

for cmd in python3 java curl sha256sum; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "ERROR: required command not found: $cmd" >&2; exit 2; }
done

python3 scripts/verify_inputs.py

mkdir -p tools build
if [[ ! -f tools/apktool.jar ]] || ! echo "${APKTOOL_SHA256}  tools/apktool.jar" | sha256sum --check --status; then
  echo "Downloading Apktool ${APKTOOL_VERSION}..."
  curl --fail --location --retry 3 "$APKTOOL_URL" --output tools/apktool.jar
fi
echo "${APKTOOL_SHA256}  tools/apktool.jar" | sha256sum --check
java -jar tools/apktool.jar --version

# AndroidForge's published image has build-tools 34.0.0 and older versions.
# Find the newest installed folder containing both required signing utilities.
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/opt/android-sdk}}"
BUILD_TOOLS_ROOT="$SDK_ROOT/build-tools"
if [[ ! -d "$BUILD_TOOLS_ROOT" ]]; then
  echo "ERROR: Android SDK build-tools directory not found: $BUILD_TOOLS_ROOT" >&2
  exit 2
fi
ANDROID_BUILD_TOOLS=""
while IFS= read -r candidate; do
  if [[ -x "$candidate/apksigner" && -x "$candidate/zipalign" ]]; then
    ANDROID_BUILD_TOOLS="$candidate"
    break
  fi
done < <(find "$BUILD_TOOLS_ROOT" -mindepth 2 -maxdepth 2 -type f -name apksigner -printf '%h\n' | sort -Vr)
if [[ -z "$ANDROID_BUILD_TOOLS" ]]; then
  echo "ERROR: no installed Android Build Tools folder contains both apksigner and zipalign" >&2
  find "$BUILD_TOOLS_ROOT" -maxdepth 2 -type f \( -name apksigner -o -name zipalign \) -print >&2 || true
  exit 2
fi
export ANDROID_BUILD_TOOLS
echo "Using Android Build Tools: $ANDROID_BUILD_TOOLS"

rm -rf build/decoded build/prepared build/output build/outputs/apk/debug
mkdir -p build

java -jar tools/apktool.jar d -f input/base.apk.source -o build/decoded
python3 scripts/set_app_name.py build/decoded
python3 scripts/patch_ads.py build/decoded
java -jar tools/apktool.jar b build/decoded -o build/base-unsigned.apk
bash scripts/package_output.sh

echo ""
echo "AndroidForge-compatible APK output directory: $ROOT/build/outputs/apk/debug"
find "$ROOT/build/outputs/apk/debug" -maxdepth 1 -type f -name '*.apk' -printf ' - %f (%s bytes)\n' | sort
