@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle 8.7 не найден. Установите Gradle 8.7 и JDK 17.
  pause
  exit /b 1
)
gradle assembleDebug
if errorlevel 1 exit /b 1
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
