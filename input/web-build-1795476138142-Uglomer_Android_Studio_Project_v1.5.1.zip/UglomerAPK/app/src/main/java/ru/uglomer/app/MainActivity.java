package ru.uglomer.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
    private static final String PREFS = "uglomer_settings";
    private static final int BLUE = Color.rgb(7, 133, 233);
    private static final int RED = Color.rgb(238, 24, 18);
    private SensorManager sensorManager;
    private Sensor sensor;
    private AngleView angleView;
    private SharedPreferences prefs;

    // Gravity vector and angle filters. All filter constants are time-based, so
    // their behaviour does not depend on the phone's sensor sampling frequency.
    private float gx, gy, gz = SensorManager.GRAVITY_EARTH;
    private float filteredGx, filteredGy, filteredGz = SensorManager.GRAVITY_EARTH;
    private float rawAngle = 0f;
    private float smoothedAngle = 0f;
    private float displayAngle = 0f;
    private long lastSensorTimestamp = 0L;
    private boolean vectorInitialized = false;
    private boolean angleInitialized = false;
    private boolean displayAngleInitialized = false;
    private float calibration = 0f;
    private float heldAngle = 0f;
    private float angle = 0f;
    private boolean hasSensor = false;
    private boolean held = false;
    private boolean percent = false;
    private final int precision = 1; // one decimal is display resolution, not accuracy
    private boolean changeMode = false;
    // First touch captures the reference line; second locks the comparison line.
    private boolean hasFixation1 = false, hasFixation2 = false;
    private float fixation1 = 0f, fixation2 = 0f;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BLUE);
        getWindow().setNavigationBarColor(BLUE);
        applyImmersiveMode();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        calibration = prefs.getFloat("calibration", 0f);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        // Prefer Android's fused gravity sensor. Use the raw accelerometer only
        // as a fallback, with a slower low-pass filter below.
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (sensor == null) sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        angleView = new AngleView(this);
        setContentView(angleView);
        if (sensor == null) {
            Toast.makeText(this, "На устройстве не найден датчик ускорения", Toast.LENGTH_LONG).show();
        }
    }

    private void applyImmersiveMode() {
        final int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override protected void onResume() {
        super.onResume();
        lastSensorTimestamp = 0L;
        vectorInitialized = false;
        angleInitialized = false;
        if (sensor != null) sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.values == null || event.values.length < 3) return;

        float dt = lastSensorTimestamp == 0L ? 0.02f
                : (event.timestamp - lastSensorTimestamp) * 1.0e-9f;
        if (dt <= 0f || dt > 0.50f) dt = 0.02f;
        lastSensorTimestamp = event.timestamp;

        boolean gravitySensor = event.sensor.getType() == Sensor.TYPE_GRAVITY;
        // Android's gravity sensor is already sensor-fused. The accelerometer
        // fallback contains linear movement as well, so it is filtered more strongly.
        float vectorTimeConstant = gravitySensor ? 0.28f : 0.55f;
        float retention = (float) Math.exp(-dt / vectorTimeConstant);
        if (!vectorInitialized) {
            // Initialize from the first real sensor sample; never blend from a
            // fictional (0, 0, g) vector, which would cause startup drift.
            filteredGx = event.values[0];
            filteredGy = event.values[1];
            filteredGz = event.values[2];
            vectorInitialized = true;
        } else {
            float inputWeight = 1f - retention;
            filteredGx = retention * filteredGx + inputWeight * event.values[0];
            filteredGy = retention * filteredGy + inputWeight * event.values[1];
            filteredGz = retention * filteredGz + inputWeight * event.values[2];
        }
        gx = filteredGx;
        gy = filteredGy;
        gz = filteredGz;

        // Convert the device-coordinate gravity vector to portrait screen axes.
        // The app is portrait-locked, but this transform also keeps the mapping
        // correct if Android reports a non-zero display rotation.
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        float screenX, screenY;
        switch (rotation) {
            case android.view.Surface.ROTATION_90:
                screenX = gy; screenY = -gx; break;
            case android.view.Surface.ROTATION_180:
                screenX = -gx; screenY = -gy; break;
            case android.view.Surface.ROTATION_270:
                screenX = -gy; screenY = gx; break;
            case android.view.Surface.ROTATION_0:
            default:
                screenX = gx; screenY = gy; break;
        }

        // Keep the same measurement plane as the previously working version.
        // The axis selector is removed; users cannot accidentally switch planes.
        float targetAngle = normalize((float) Math.toDegrees(Math.atan2(-screenX, gz)));
        if (!angleInitialized) {
            smoothedAngle = targetAngle;
            angleInitialized = true;
        } else {
            float angleTimeConstant = gravitySensor ? 0.24f : 0.32f;
            float alpha = 1f - (float) Math.exp(-dt / angleTimeConstant);
            float difference = normalize(targetAngle - smoothedAngle);
            // Suppress very small residual noise without preventing cumulative tilt changes.
            if (Math.abs(difference) < 0.025f) difference = 0f;
            smoothedAngle = normalize(smoothedAngle + alpha * difference);
        }

        rawAngle = smoothedAngle;
        angle = held ? heldAngle : stabilizeDisplayAngle(normalize(rawAngle - calibration));
        hasSensor = true;
        if (angleView != null) angleView.postInvalidateOnAnimation();
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private static float normalize(float value) {
        while (value > 180f) value -= 360f;
        while (value < -180f) value += 360f;
        return value;
    }

    private String format(float value, int digits) {
        float epsilon = (float) (0.5 * Math.pow(10, -digits));
        if (Math.abs(value) < epsilon) value = 0f;
        return String.format(Locale.getDefault(), "% ." + digits + "f", value).trim().replace('.', ',').replace('-', '−');
    }

    private String readingText() {
        float a = angle;
        if (percent) return format((float) Math.tan(Math.toRadians(a)) * 100f, precision) + "%";
        return format(a, precision) + "°";
    }

    /**
     * One-decimal display quantizer with a Schmitt deadband. It prevents the
     * displayed tenth from flickering when a stationary sensor hovers near a
     * rounding boundary. This improves readability, not absolute accuracy.
     */
    private float stabilizeDisplayAngle(float value) {
        final float step = 0.1f;
        final float boundaryHysteresis = 0.03f;
        if (!displayAngleInitialized) {
            displayAngle = normalize(Math.round(value / step) * step);
            displayAngleInitialized = true;
            return displayAngle;
        }

        float difference = normalize(value - displayAngle);
        float boundary = step * 0.5f + boundaryHysteresis;
        if (difference > boundary) {
            int steps = Math.max(1, (int) Math.floor((difference - boundary) / step) + 1);
            displayAngle = normalize(displayAngle + steps * step);
        } else if (difference < -boundary) {
            int steps = Math.max(1, (int) Math.floor((-difference - boundary) / step) + 1);
            displayAngle = normalize(displayAngle - steps * step);
        }
        return displayAngle;
    }

    private void saveSettings() {
        prefs.edit().putFloat("calibration", calibration).apply();
    }

    private void toggleChangeMode() {
        changeMode = !changeMode;
        hasFixation1 = false;
        hasFixation2 = false;
        angleView.invalidate();
    }

    private void toggleHold() {
        if (!held) {
            heldAngle = angle;
            held = true;
        } else {
            held = false;
            angle = stabilizeDisplayAngle(normalize(rawAngle - calibration));
        }
        angleView.invalidate();
    }

    private void showSettings() {
        final String[] items = new String[] {
                "Принять текущее положение за 0°",
                "Сбросить калибровку",
                "О приложении"
        };
        new AlertDialog.Builder(this)
                .setTitle("Настройки угломера")
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            calibration = rawAngle;
                            held = false;
                            displayAngleInitialized = false;
                            angle = stabilizeDisplayAngle(0f);
                            Toast.makeText(this, "Текущее положение принято за 0°", Toast.LENGTH_SHORT).show();
                            break;
                        case 1:
                            calibration = 0f;
                            held = false;
                            displayAngleInitialized = false;
                            angle = stabilizeDisplayAngle(rawAngle);
                            Toast.makeText(this, "Калибровка сброшена", Toast.LENGTH_SHORT).show();
                            break;
                        case 2:
                            new AlertDialog.Builder(this).setTitle("Угломер")
                                    .setMessage("Автономный инклинометр. Угол рассчитывается по вектору гравитации, получаемому от датчика Android. Значения отображаются с шагом 0,1°, но это не означает абсолютную погрешность 0,1°. Фактическая точность зависит от датчика, калибровки, температуры и устойчивости установки телефона. Для точных измерений сравнивайте показания с поверенным угломером.")
                                    .setPositiveButton("ОК", null).show();
                            return;
                    }
                    saveSettings();
                    angleView.invalidate();
                })
                .setNegativeButton("Готово", null)
                .show();
    }

    private class AngleView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float density;
        private float downX, downY;
        private boolean touchHandled;
        // Separate text-orientation branches for the live and the two captured labels.
        private final boolean[] textFlipped = new boolean[3];

        AngleView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            // Keep Android hardware acceleration enabled for smooth 60 Hz redraws.
            setFocusable(true);
        }

        private float dp(float v) { return v * density; }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            // Use the stabilized, quantized presentation angle for both the divider
            // and its label, so the graphic cannot visibly drift while the number holds.
            float liveAngle = angle;
            canvas.drawColor(Color.WHITE);

            if (hasFixation1) {
                // The first captured angle remains fixed. Until the second tap, the other
                // divider follows the live sensor; after the second tap both dividers freeze.
                float secondAngle = hasFixation2 ? fixation2 : liveAngle;
                drawDualField(canvas, w, h, fixation1, secondAngle);
                drawDualReadings(canvas, w, h, fixation1, secondAngle);
            } else {
                drawSingleField(canvas, w, h, liveAngle);
                drawSingleReading(canvas, w, h, liveAngle);
            }

            drawCrosshairAndMarkers(canvas, w, h);
            drawCaptureStateIcon(canvas);
            drawUnitButton(canvas, w, h);
            drawActions(canvas, w, h);
            if (!hasSensor) drawSensorWarning(canvas, w, h);
        }

        /** Original two-colour live view: blue on the positive side, white on the negative side. */
        private void drawSingleField(Canvas c, float w, float h, float angleDeg) {
            float extent = (float) Math.hypot(w, h) * 2.2f;
            Path blueSide = halfPlanePath(w * .5f, h * .5f, angleDeg, true, extent);
            p.setStyle(Paint.Style.FILL);
            p.setColor(BLUE);
            c.drawPath(blueSide, p);
            drawBoundary(c, w, h, angleDeg, 0xFFEAF5FE);
        }

        /**
         * Two captured planes create the three-colour reference graphic:
         * equal half-plane signs => blue (positive/positive) or white (negative/negative);
         * opposite signs => red. This is the same four-sector geometry as the reference image.
         */
        private void drawDualField(Canvas c, float w, float h, float first, float second) {
            float cx = w * .5f, cy = h * .5f;
            float extent = (float) Math.hypot(w, h) * 2.2f;
            Path firstPos = halfPlanePath(cx, cy, first, true, extent);
            Path firstNeg = halfPlanePath(cx, cy, first, false, extent);
            Path secondPos = halfPlanePath(cx, cy, second, true, extent);
            Path secondNeg = halfPlanePath(cx, cy, second, false, extent);

            // Red occupies the two sectors where the two signed plane tests disagree.
            p.setStyle(Paint.Style.FILL);
            p.setColor(RED);
            c.save(); c.clipPath(firstPos); c.clipPath(secondNeg);
            c.drawColor(RED); c.restore();
            c.save(); c.clipPath(firstNeg); c.clipPath(secondPos);
            c.drawColor(RED); c.restore();

            // The remaining positive/positive sector is blue; negative/negative stays white.
            c.save(); c.clipPath(firstPos); c.clipPath(secondPos);
            c.drawColor(BLUE); c.restore();

            drawBoundary(c, w, h, first, 0xBFFFFFFF);
            drawBoundary(c, w, h, second, 0xBFFFFFFF);
        }

        private Path halfPlanePath(float cx, float cy, float angleDeg, boolean positive, float extent) {
            double a = Math.toRadians(angleDeg);
            float nx = (float) Math.cos(a), ny = (float) Math.sin(a);
            float tx = -ny, ty = nx;
            float sign = positive ? 1f : -1f;
            Path out = new Path();
            out.moveTo(cx - tx * extent, cy - ty * extent);
            out.lineTo(cx + tx * extent, cy + ty * extent);
            out.lineTo(cx + tx * extent + nx * extent * sign, cy + ty * extent + ny * extent * sign);
            out.lineTo(cx - tx * extent + nx * extent * sign, cy - ty * extent + ny * extent * sign);
            out.close();
            return out;
        }

        private void drawBoundary(Canvas c, float w, float h, float angleDeg, int color) {
            double a = Math.toRadians(angleDeg);
            float nx = (float) Math.cos(a), ny = (float) Math.sin(a);
            float tx = -ny, ty = nx;
            float extent = (float) Math.hypot(w, h) * 2.2f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(dp(1.25f));
            p.setColor(color);
            c.drawLine(w * .5f - tx * extent, h * .5f - ty * extent,
                    w * .5f + tx * extent, h * .5f + ty * extent, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawCrosshairAndMarkers(Canvas c, float w, float h) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setStrokeWidth(dp(2.2f));
            p.setColor(Color.WHITE); p.setAlpha(225);
            c.drawLine(w * .5f, 0, w * .5f, h * .066f, p);
            c.drawLine(0, h * .5f, w * .143f, h * .5f, p);
            p.setColor(BLUE); p.setAlpha(210);
            c.drawLine(w * .5f, h * .934f, w * .5f, h, p);
            c.drawLine(w * .857f, h * .5f, w, h * .5f, p);
            p.setAlpha(255);
            p.setStrokeWidth(dp(2f));
            c.drawLine(w * .5f, h * .468f, w * .5f, h * .532f, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawSingleReading(Canvas c, float w, float h, float angleDeg) {
            String value = angleText(angleDeg);
            float size = readingTextSize(w, h);
            float cx = w * .5f, cy = h * .5f;
            double a = Math.toRadians(angleDeg);
            float tx = (float) -Math.sin(a), ty = (float) Math.cos(a);
            float offset = Math.min(w, h) * .235f;
            float rot = readableRotation(angleDeg + 90f, 0);
            drawAdaptiveTextSingle(c, w, h, value, cx + tx * offset, cy + ty * offset, rot, size, angleDeg);
        }

        private void drawDualReadings(Canvas c, float w, float h, float first, float second) {
            float size = readingTextSize(w, h);
            float cx = w * .5f, cy = h * .5f;
            float offset = Math.min(w, h) * .225f;
            double a1 = Math.toRadians(first), a2 = Math.toRadians(second);
            float t1x = (float) -Math.sin(a1), t1y = (float) Math.cos(a1);
            float t2x = (float) -Math.sin(a2), t2y = (float) Math.cos(a2);

            // Put the two values on opposite sides of the crosshair, aligned with their own divider.
            drawAdaptiveTextDual(c, w, h, angleText(first),
                    cx - t1x * offset, cy - t1y * offset, readableRotation(first + 90f, 1), size, first, second);
            drawAdaptiveTextDual(c, w, h, angleText(second),
                    cx + t2x * offset, cy + t2y * offset, readableRotation(second + 90f, 2), size, first, second);
        }

        private float readingTextSize(float w, float h) {
            return Math.max(dp(40), Math.min(dp(68), Math.min(w, h) * .105f));
        }

        private float readableRotation(float degrees, int labelIndex) {
            float a = normalize(degrees);
            boolean flipped = textFlipped[labelIndex];
            // Keep text upright. Switch branches as soon as the baseline crosses
            // vertical, but only switch back after it has moved 10 degrees away.
            // This hysteresis prevents repeated 180-degree flips caused by tiny
            // sensor noise while the phone is almost vertical.
            if (!flipped && Math.abs(a) > 90f) {
                flipped = true;
            } else if (flipped && Math.abs(a) < 80f) {
                flipped = false;
            }
            textFlipped[labelIndex] = flipped;
            if (flipped) a += (a > 0f ? -180f : 180f);
            // At the hysteresis edge, keep the baseline exactly vertical rather
            // than allowing text to cross into an upside-down orientation.
            return Math.max(-90f, Math.min(90f, a));
        }

        private String angleText(float value) {
            if (percent) return format((float) Math.tan(Math.toRadians(value)) * 100f, 1) + "%";
            return format(value, 1) + "°";
        }

        /** Text is clipped by the very same animated regions as the background. */
        private void drawAdaptiveTextSingle(Canvas c, float w, float h, String text,
                                            float x, float y, float rotation, float textSize, float angleDeg) {
            float extent = (float) Math.hypot(w, h) * 2.2f;
            Path blueSide = halfPlanePath(w * .5f, h * .5f, angleDeg, true, extent);
            Path whiteSide = halfPlanePath(w * .5f, h * .5f, angleDeg, false, extent);
            drawTextInClip(c, text, x, y, rotation, textSize, Color.WHITE, blueSide);
            drawTextInClip(c, text, x, y, rotation, textSize, BLUE, whiteSide);
        }

        private void drawAdaptiveTextDual(Canvas c, float w, float h, String text,
                                          float x, float y, float rotation, float textSize,
                                          float first, float second) {
            float cx = w * .5f, cy = h * .5f;
            float extent = (float) Math.hypot(w, h) * 2.2f;
            Path firstPos = halfPlanePath(cx, cy, first, true, extent);
            Path firstNeg = halfPlanePath(cx, cy, first, false, extent);
            Path secondPos = halfPlanePath(cx, cy, second, true, extent);
            Path secondNeg = halfPlanePath(cx, cy, second, false, extent);

            // Blue area: white digits.
            drawTextInClip(c, text, x, y, rotation, textSize, Color.WHITE, firstPos, secondPos);
            // White area: blue digits.
            drawTextInClip(c, text, x, y, rotation, textSize, BLUE, firstNeg, secondNeg);
            // Both red sectors: white digits.
            drawTextInClip(c, text, x, y, rotation, textSize, Color.WHITE, firstPos, secondNeg);
            drawTextInClip(c, text, x, y, rotation, textSize, Color.WHITE, firstNeg, secondPos);
        }

        private void drawTextInClip(Canvas c, String text, float x, float y, float rotation,
                                    float textSize, int color, Path... clips) {
            c.save();
            for (Path clip : clips) c.clipPath(clip);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setAlpha(255);
            p.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
            p.setTextSize(textSize);
            p.setTextAlign(Paint.Align.CENTER);
            p.clearShadowLayer();
            c.save();
            c.translate(x, y);
            c.rotate(rotation);
            float baseline = -(p.ascent() + p.descent()) * .5f;
            c.drawText(text, 0f, baseline, p);
            c.restore();
            c.restore();
        }

        /**
         * Capture state indicator in the upper-left corner:
         * first tap = protractor icon; second tap = padlock icon; unlocked = no icon.
         */
        private void drawCaptureStateIcon(Canvas c) {
            if (!hasFixation1) return;
            float cx = dp(47f);
            float cy = dp(47f);
            float s = dp(27f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(dp(2.5f));
            p.setColor(Color.WHITE);
            p.setAlpha(255);
            p.setShadowLayer(dp(1.5f), 0f, dp(1f), 0x88000000);

            if (!hasFixation2) {
                // Simple recognizable angle-measurer / protractor pictogram.
                RectF arc = new RectF(cx - s * .68f, cy - s * .68f,
                        cx + s * .68f, cy + s * .68f);
                c.drawArc(arc, 180f, 180f, false, p);
                c.drawLine(cx - s * .78f, cy + s * .12f,
                        cx + s * .78f, cy + s * .12f, p);
                c.drawLine(cx, cy + s * .12f, cx + s * .43f, cy - s * .50f, p);
                for (int i = 0; i <= 6; i++) {
                    double a = Math.PI + Math.PI * i / 6.0;
                    float x1 = cx + (float)Math.cos(a) * s * .55f;
                    float y1 = cy + (float)Math.sin(a) * s * .55f;
                    float x2 = cx + (float)Math.cos(a) * s * .68f;
                    float y2 = cy + (float)Math.sin(a) * s * .68f;
                    c.drawLine(x1, y1, x2, y2, p);
                }
            } else {
                // Padlock: curved shackle plus a rounded rectangular body and keyhole.
                RectF shackle = new RectF(cx - s * .38f, cy - s * .72f,
                        cx + s * .38f, cy + s * .18f);
                c.drawArc(shackle, 180f, 180f, false, p);
                RectF body = new RectF(cx - s * .58f, cy - s * .13f,
                        cx + s * .58f, cy + s * .78f);
                c.drawRoundRect(body, dp(3f), dp(3f), p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy + s * .20f, dp(2.2f), p);
                p.setStyle(Paint.Style.STROKE);
                c.drawLine(cx, cy + s * .23f, cx, cy + s * .40f, p);
            }
            p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);
        }

        private void drawUnitButton(Canvas c, float w, float h) {
            float r = Math.max(dp(22), Math.min(dp(30), Math.min(w, h) * .047f));
            float cx = w - r - dp(40), cy = dp(42) + r * .3f;
            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE);
            c.drawCircle(cx, cy, r, p);
            c.save(); c.clipRect(cx - r - 1, cy, cx + r + 1, cy + r + 1);
            p.setColor(BLUE); c.drawCircle(cx, cy, r - dp(1), p); c.restore();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(BLUE);
            c.drawCircle(cx, cy, r, p);
            if (percent) {
                p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(r * 1.0f); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                c.drawText("%", cx, cy + r * .35f, p);
            }
        }

        private void drawActions(Canvas c, float w, float h) {
            float r = Math.max(dp(25), Math.min(dp(36), Math.min(w, h) * .055f));
            float cx = w - r - dp(34);
            boolean portrait = h >= w;
            float gap = r * 2.65f;
            float firstY = portrait ? h * .67f : h * .5f - gap;
            float y1 = firstY, y2 = firstY + gap, y3 = firstY + gap * 2f;
            drawActionCircle(c, cx, y1, r, 0);
            drawActionCircle(c, cx, y2, r, held ? 1 : 2);
            drawActionCircle(c, cx, y3, r, 3, changeMode);
        }

        private void drawActionCircle(Canvas c, float cx, float cy, float r, int icon) {
            drawActionCircle(c, cx, cy, r, icon, false);
        }

        private void drawActionCircle(Canvas c, float cx, float cy, float r, int icon, boolean active) {
            boolean modeButtonActive = icon == 3 && active;
            p.setStyle(Paint.Style.FILL);
            p.setColor(modeButtonActive ? Color.WHITE : BLUE);
            p.setShadowLayer(dp(3), 0, dp(2), 0x22000000);
            c.drawCircle(cx, cy, r, p);
            p.clearShadowLayer();
            int glyphColor = modeButtonActive ? BLUE : Color.WHITE;
            p.setColor(glyphColor);
            p.setStrokeWidth(dp(2.5f));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStyle(Paint.Style.STROKE);

            if (icon == 0) {
                // Settings gear.
                c.drawCircle(cx, cy, r * .43f, p);
                c.drawCircle(cx, cy, r * .19f, p);
                for (int i = 0; i < 8; i++) {
                    double t = i * Math.PI / 4;
                    c.drawLine(cx + (float)Math.cos(t)*r*.5f, cy + (float)Math.sin(t)*r*.5f,
                            cx + (float)Math.cos(t)*r*.68f, cy + (float)Math.sin(t)*r*.68f, p);
                }
            } else if (icon == 1 || icon == 2) {
                // Hold indicator / target.
                c.drawCircle(cx, cy, r * .58f, p);
                c.drawCircle(cx, cy, r * .32f, p);
                for (int i = 0; i < 4; i++) {
                    double t = i * Math.PI / 2;
                    c.drawLine(cx + (float)Math.cos(t)*r*.72f, cy + (float)Math.sin(t)*r*.72f,
                            cx + (float)Math.cos(t)*r*.9f, cy + (float)Math.sin(t)*r*.9f, p);
                }
                if (icon == 1) {
                    p.setStyle(Paint.Style.FILL);
                    c.drawRect(cx-r*.11f, cy-r*.22f, cx-r*.025f, cy+r*.22f, p);
                    c.drawRect(cx+r*.025f, cy-r*.22f, cx+r*.11f, cy+r*.22f, p);
                }
            } else {
                // Measurement mode: a target ring with a marked measuring axis.
                c.drawCircle(cx, cy, r * .60f, p);
                c.drawLine(cx-r*.42f, cy, cx+r*.42f, cy, p);
                c.drawLine(cx, cy-r*.42f, cx, cy+r*.42f, p);
                c.drawLine(cx-r*.25f, cy+r*.25f, cx+r*.25f, cy-r*.25f, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, r*.10f, p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        private void drawSensorWarning(Canvas c, float w, float h) {
            String t = "ДАТЧИК НЕ ОБНАРУЖЕН";
            p.setColor(0xCC173B59); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(12));
            c.drawText(t, w * .5f, h - dp(26), p);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = e.getX();
                downY = e.getY();
                touchHandled = true;
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP && touchHandled) {
                float w = getWidth(), h = getHeight();
                float r = Math.max(dp(25), Math.min(dp(36), Math.min(w, h) * .055f));
                float cx = w - r - dp(34);
                float unitR = Math.max(dp(22), Math.min(dp(30), Math.min(w, h) * .047f));
                float ux = w - unitR - dp(40), uy = dp(42) + unitR * .3f;
                boolean isTap = distance(downX, downY, e.getX(), e.getY()) < dp(24);
                if (isTap) {
                    if (distance(downX, downY, ux, uy) < unitR * 1.8f) {
                        percent = !percent;
                    } else {
                        boolean portrait = h >= w;
                        float gap = r * 2.65f;
                        float firstY = portrait ? h * .67f : h * .5f - gap;
                        if (distance(downX, downY, cx, firstY) < r * 1.7f) {
                            showSettings();
                        } else if (distance(downX, downY, cx, firstY + gap) < r * 1.7f) {
                            toggleHold();
                        } else if (distance(downX, downY, cx, firstY + gap * 2f) < r * 1.7f) {
                            // The former axis button now enables/disables measurement mode.
                            toggleChangeMode();
                        } else if (changeMode) {
                            // Free-screen taps do not activate the mode. They only
                            // capture the first and second references after it is enabled.
                            captureFixation();
                        }
                    }
                }
                invalidate();
                touchHandled = false;
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_CANCEL) touchHandled = false;
            return true;
        }

        private void captureFixation() {
            if (!changeMode) return;

            // Third tap unlocks the pair, leaves measurement mode and is the only
            // capture-related action that displays a toast.
            if (hasFixation2) {
                hasFixation1 = false;
                hasFixation2 = false;
                textFlipped[0] = false;
                textFlipped[1] = false;
                textFlipped[2] = false;
                fixation1 = 0f;
                fixation2 = 0f;
                changeMode = false;
                invalidate();
                Toast.makeText(MainActivity.this, "Разблокировано", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!hasSensor) return;

            float snapshot = angle;
            if (!hasFixation1) {
                textFlipped[1] = false;
                textFlipped[2] = false;
                fixation1 = snapshot;
                hasFixation1 = true;
                hasFixation2 = false;
            } else {
                fixation2 = snapshot;
                hasFixation2 = true;
            }
            invalidate();
        }

        private float distance(float x1, float y1, float x2, float y2) {
            float dx = x1 - x2, dy = y1 - y2; return (float)Math.sqrt(dx*dx + dy*dy);
        }
    }
}
