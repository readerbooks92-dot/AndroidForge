#!/usr/bin/env python3
"""Verify the supplied APK split set against the export manifest."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
MANIFEST = INPUT / "manifest.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    if not MANIFEST.is_file():
        print(f"ERROR: missing {MANIFEST}", file=sys.stderr)
        return 2
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if data.get("packageName") != "org.nixgame.bubblelevel":
        print("ERROR: unexpected packageName in input/manifest.json", file=sys.stderr)
        return 2
    if data.get("versionName") != "8.7-release" or data.get("versionCode") != 87:
        print("ERROR: unexpected app version in input/manifest.json", file=sys.stderr)
        return 2

    errors = []
    for item in data.get("apks", []):
        path = INPUT / item["file"]
        if not path.is_file():
            errors.append(f"missing: {item['file']}")
            continue
        actual = sha256(path)
        if actual != item["sha256"]:
            errors.append(f"SHA-256 mismatch: {item['file']}")
        if path.stat().st_size != item["bytes"]:
            errors.append(f"size mismatch: {item['file']}")

    if errors:
        print("Input validation failed:", file=sys.stderr)
        for error in errors:
            print(f" - {error}", file=sys.stderr)
        return 1
    print("Input APK set verified:")
    print(f"  package: {data['packageName']}")
    print(f"  version: {data['versionName']} ({data['versionCode']})")
    print(f"  APK parts: {len(data['apks'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
