package ru.uglomer.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
    private static final String PREFS = "uglomer_settings";
    private static final int BLUE = Color.rgb(7, 133, 233);
    private SensorManager sensorManager;
    private Sensor sensor;
    private AngleView angleView;
    private SharedPreferences prefs;
    private Vibrator vibrator;
    private ToneGenerator tone;

    private float gx, gy, gz = SensorManager.GRAVITY_EARTH;
    private float rawAngle = 0f;
    private float smoothedAngle = 0f;
    private long lastSensorTimestamp = 0L;
    private boolean angleInitialized = false;
    private float calibration = 0f;
    private float heldAngle = 0f;
    private float angle = 0f;
    private boolean hasSensor = false;
    private boolean held = false;
    private boolean percent = false;
    private boolean soundEnabled = false;
    private boolean vibrationEnabled = true;
    private boolean lastWasLevel = false;
    private boolean haveGravityVector = false;
    private int precision = 1;       // 0, 1 or 2 decimal places
    private int axisMode = 0;         // 0 auto, 1 screen X, 2 screen Y
    private float threshold = 0.2f;
    private float[] filtered = new float[]{0f, 0f, SensorManager.GRAVITY_EARTH};

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BLUE);
        getWindow().setNavigationBarColor(BLUE);
        applyImmersiveMode();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        precision = prefs.getInt("precision", 1);
        axisMode = prefs.getInt("axisMode", 0);
        soundEnabled = prefs.getBoolean("sound", false);
        vibrationEnabled = prefs.getBoolean("vibration", true);
        threshold = prefs.getFloat("threshold", 0.2f);
        calibration = prefs.getFloat("calibration", 0f);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (sensor == null) sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        try { tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70); } catch (Exception ignored) { }

        angleView = new AngleView(this);
        setContentView(angleView);
        if (sensor == null) {
            Toast.makeText(this, "На устройстве не найден датчик ускорения", Toast.LENGTH_LONG).show();
        }
    }

    private void applyImmersiveMode() {
        final int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override protected void onResume() {
        super.onResume();
        if (sensor != null) sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.values == null || event.values.length < 3) return;

        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            // Time-independent vector low-pass: attenuates hand tremor and sensor noise.
            final float vectorAlpha = 0.88f;
            filtered[0] = vectorAlpha * filtered[0] + (1f - vectorAlpha) * event.values[0];
            filtered[1] = vectorAlpha * filtered[1] + (1f - vectorAlpha) * event.values[1];
            filtered[2] = vectorAlpha * filtered[2] + (1f - vectorAlpha) * event.values[2];
            gx = filtered[0]; gy = filtered[1]; gz = filtered[2];
        } else {
            gx = event.values[0]; gy = event.values[1]; gz = event.values[2];
        }

        // Convert device coordinates to the fixed portrait screen coordinates.
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        float screenX, screenY;
        switch (rotation) {
            case android.view.Surface.ROTATION_90:
                screenX = gy; screenY = -gx; break;
            case android.view.Surface.ROTATION_180:
                screenX = -gx; screenY = -gy; break;
            case android.view.Surface.ROTATION_270:
                screenX = -gy; screenY = gx; break;
            case android.view.Surface.ROTATION_0:
            default:
                screenX = gx; screenY = gy; break;
        }

        // In portrait mode Auto uses the long (vertical) phone axis.
        boolean useY = axisMode == 2;
        float component = useY ? screenY : screenX;
        float targetAngle = normalize((float) Math.toDegrees(
                Math.atan2(-component, gz)));

        // Smooth the angle itself using the shortest path around the -180/180 boundary.
        // This avoids both visible jitter and a false jump when the reading wraps.
        if (!angleInitialized) {
            smoothedAngle = targetAngle;
            angleInitialized = true;
        } else {
            float dt = (event.timestamp - lastSensorTimestamp) * 1.0e-9f;
            if (dt <= 0f || dt > 0.25f) dt = 0.02f;
            final float timeConstant = event.sensor.getType() == Sensor.TYPE_GRAVITY ? 0.16f : 0.28f;
            float alpha = 1f - (float) Math.exp(-dt / timeConstant);
            float difference = normalize(targetAngle - smoothedAngle);
            // Small deadband suppresses sub-hundredth-degree sensor chatter at rest.
            if (Math.abs(difference) < 0.025f) difference = 0f;
            smoothedAngle = normalize(smoothedAngle + alpha * difference);
        }
        lastSensorTimestamp = event.timestamp;
        rawAngle = smoothedAngle;
        angle = held ? heldAngle : normalize(rawAngle - calibration);
        hasSensor = true;
        if (!held) updateLevelFeedback(angle);
        if (angleView != null) angleView.postInvalidateOnAnimation();
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private static float normalize(float value) {
        while (value > 180f) value -= 360f;
        while (value < -180f) value += 360f;
        return value;
    }

    private void updateLevelFeedback(float a) {
        boolean level = Math.abs(a) <= threshold;
        if (level && !lastWasLevel) {
            if (vibrationEnabled && vibrator != null && vibrator.hasVibrator()) {
                try {
                    if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE));
                    else vibrator.vibrate(30);
                } catch (SecurityException ignored) { }
            }
            if (soundEnabled && tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 90);
        }
        lastWasLevel = level;
    }

    private String format(float value, int digits) {
        float epsilon = (float) (0.5 * Math.pow(10, -digits));
        if (Math.abs(value) < epsilon) value = 0f;
        return String.format(Locale.getDefault(), "% ." + digits + "f", value).trim().replace('.', ',').replace('-', '−');
    }

    private String readingText() {
        float a = held ? heldAngle : normalize(rawAngle - calibration);
        if (percent) return format((float) Math.tan(Math.toRadians(a)) * 100f, precision) + "%";
        return format(a, precision) + "°";
    }

    private String axisLabel() {
        if (axisMode == 1) return "Ось X";
        if (axisMode == 2) return "Ось Y";
        return "Авто";
    }

    private void saveSettings() {
        prefs.edit().putInt("precision", precision).putInt("axisMode", axisMode)
                .putBoolean("sound", soundEnabled).putBoolean("vibration", vibrationEnabled)
                .putFloat("threshold", threshold).putFloat("calibration", calibration).apply();
    }

    private void toggleHold() {
        if (!held) {
            heldAngle = normalize(rawAngle - calibration);
            held = true;
        } else held = false;
        angle = held ? heldAngle : normalize(rawAngle - calibration);
        angleView.invalidate();
    }

    private void toggleAxis() {
        axisMode = (axisMode + 1) % 3;
        saveSettings();
        Toast.makeText(this, "Ось: " + axisLabel(), Toast.LENGTH_SHORT).show();
        angleView.invalidate();
    }

    private void showSettings() {
        final String[] items = new String[] {
                "Точность: " + new String[]{"1°", "0,1°", "0,01°"}[precision],
                "Ось измерения: " + axisLabel(),
                "Звуковой сигнал: " + (soundEnabled ? "включён" : "выключен"),
                "Вибрация: " + (vibrationEnabled ? "включена" : "выключена"),
                "Порог ровного положения: ±" + String.format(Locale.getDefault(), "%.1f", threshold).replace('.', ',') + "°",
                "Принять текущее положение за 0°",
                "Сбросить калибровку",
                "О приложении"
        };
        new AlertDialog.Builder(this)
                .setTitle("Настройки угломера")
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0: precision = (precision + 1) % 3; break;
                        case 1: axisMode = (axisMode + 1) % 3; break;
                        case 2: soundEnabled = !soundEnabled; break;
                        case 3: vibrationEnabled = !vibrationEnabled; break;
                        case 4:
                            threshold = threshold < 0.15f ? 0.2f : (threshold < 0.35f ? 0.5f : (threshold < 0.75f ? 1f : 0.1f));
                            break;
                        case 5:
                            calibration = rawAngle;
                            held = false;
                            Toast.makeText(this, "Текущее положение принято за 0°", Toast.LENGTH_SHORT).show();
                            break;
                        case 6:
                            calibration = 0f;
                            held = false;
                            Toast.makeText(this, "Калибровка сброшена", Toast.LENGTH_SHORT).show();
                            break;
                        case 7:
                            new AlertDialog.Builder(this).setTitle("Угломер")
                                    .setMessage("Автономный строительный угломер. Измерения выполняются встроенным датчиком ускорения/гравитации телефона. Точность зависит от датчика и положения устройства.")
                                    .setPositiveButton("ОК", null).show();
                            return;
                    }
                    saveSettings();
                    angleView.invalidate();
                    showSettings();
                })
                .setNegativeButton("Готово", null)
                .show();
    }

    private class AngleView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float density;
        private float downX, downY;
        private boolean touchHandled;

        AngleView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            // Keep Android hardware acceleration enabled for smooth 60 Hz redraws.
            setFocusable(true);
        }

        private float dp(float v) { return v * density; }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            canvas.drawColor(Color.WHITE);
            float a = held ? heldAngle : normalize(rawAngle - calibration);
            // Rotate the dividing line through the complete circle. The blue half-plane
            // is always on the negative-normal side, matching the reference at 0 degrees.
            double radians = Math.toRadians(a);
            float nx = (float) Math.cos(radians);
            float ny = (float) Math.sin(radians);
            float tx = -ny;
            float ty = nx;
            float cx = w * 0.5f, cy = h * 0.5f;
            float extent = (float) Math.hypot(w, h) * 2.2f;

            p.setColor(BLUE); p.setStyle(Paint.Style.FILL); p.setAlpha(255);
            path.reset();
            path.moveTo(cx - tx * extent, cy - ty * extent);
            path.lineTo(cx + tx * extent, cy + ty * extent);
            path.lineTo(cx + tx * extent - nx * extent, cy + ty * extent - ny * extent);
            path.lineTo(cx - tx * extent - nx * extent, cy - ty * extent - ny * extent);
            path.close();
            canvas.drawPath(path, p);

            // A fine boundary is visible at every angle, including near +/-90 and 180 degrees.
            p.setColor(0xFFEAF5FE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.1f));
            canvas.drawLine(cx - tx * extent, cy - ty * extent,
                    cx + tx * extent, cy + ty * extent, p);
            p.setStyle(Paint.Style.FILL);

            // Short edge markers and the central crosshair reproduce the reference level interface.
            p.setStrokeWidth(dp(2.2f));
            p.setColor(Color.WHITE); p.setAlpha(225);
            canvas.drawLine(w * .5f, 0, w * .5f, h * .066f, p);
            canvas.drawLine(0, h * .5f, w * .143f, h * .5f, p);
            p.setColor(BLUE); p.setAlpha(210);
            canvas.drawLine(w * .5f, h * .934f, w * .5f, h, p);
            canvas.drawLine(w * .857f, h * .5f, w, h * .5f, p);
            p.setAlpha(255);
            p.setStrokeWidth(dp(2f));
            canvas.drawLine(w * .5f, h * .468f, w * .5f, h * .532f, p);

            drawUnitButton(canvas, w, h);
            drawActions(canvas, w, h);
            drawReading(canvas, w, h, a);
            if (!hasSensor) drawSensorWarning(canvas, w, h);
        }

        private void drawReading(Canvas c, float w, float h, float a) {
            String text;
            if (percent) text = format((float) Math.tan(Math.toRadians(a)) * 100f, precision) + "%";
            else text = format(a, precision) + "°";
            p.setColor(BLUE); p.setAlpha(255); p.setStyle(Paint.Style.FILL);
            p.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
            p.setTextSize(Math.max(dp(43), Math.min(dp(69), Math.min(w, h) * .105f)));
            p.setTextAlign(Paint.Align.CENTER);
            c.save();
            c.rotate(90f, w * .66f, h * .405f);
            c.drawText(text, w * .66f, h * .405f + p.getTextSize() * .34f, p);
            c.restore();
        }

        private void drawUnitButton(Canvas c, float w, float h) {
            float r = Math.max(dp(22), Math.min(dp(30), Math.min(w, h) * .047f));
            float cx = w - r - dp(40), cy = dp(42) + r * .3f;
            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE);
            c.drawCircle(cx, cy, r, p);
            c.save(); c.clipRect(cx - r - 1, cy, cx + r + 1, cy + r + 1);
            p.setColor(BLUE); c.drawCircle(cx, cy, r - dp(1), p); c.restore();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(BLUE);
            c.drawCircle(cx, cy, r, p);
            if (percent) {
                p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(r * 1.0f); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                c.drawText("%", cx, cy + r * .35f, p);
            }
        }

        private void drawActions(Canvas c, float w, float h) {
            float r = Math.max(dp(25), Math.min(dp(36), Math.min(w, h) * .055f));
            float cx = w - r - dp(34);
            boolean portrait = h >= w;
            float gap = r * 2.65f;
            float firstY = portrait ? h * .67f : h * .5f - gap;
            float y1 = firstY, y2 = firstY + gap, y3 = firstY + gap * 2f;
            drawActionCircle(c, cx, y1, r, 0);
            drawActionCircle(c, cx, y2, r, held ? 1 : 2);
            drawActionCircle(c, cx, y3, r, 3);
        }

        private void drawActionCircle(Canvas c, float cx, float cy, float r, int icon) {
            p.setStyle(Paint.Style.FILL); p.setColor(BLUE);
            p.setShadowLayer(dp(3), 0, dp(2), 0x22000000);
            c.drawCircle(cx, cy, r, p); p.clearShadowLayer();
            p.setColor(Color.WHITE); p.setStrokeWidth(dp(2.5f)); p.setStyle(Paint.Style.STROKE);
            if (icon == 0) {
                c.drawCircle(cx, cy, r * .43f, p); c.drawCircle(cx, cy, r * .19f, p);
                for (int i = 0; i < 8; i++) {
                    double t = i * Math.PI / 4;
                    c.drawLine(cx + (float)Math.cos(t)*r*.5f, cy + (float)Math.sin(t)*r*.5f,
                            cx + (float)Math.cos(t)*r*.68f, cy + (float)Math.sin(t)*r*.68f, p);
                }
            } else if (icon == 1 || icon == 2) {
                c.drawCircle(cx, cy, r * .58f, p); c.drawCircle(cx, cy, r * .32f, p);
                for (int i = 0; i < 4; i++) {
                    double t = i * Math.PI / 2;
                    c.drawLine(cx + (float)Math.cos(t)*r*.72f, cy + (float)Math.sin(t)*r*.72f,
                            cx + (float)Math.cos(t)*r*.9f, cy + (float)Math.sin(t)*r*.9f, p);
                }
                if (icon == 1) {
                    p.setStyle(Paint.Style.FILL);
                    c.drawRect(cx-r*.11f, cy-r*.22f, cx-r*.025f, cy+r*.22f, p);
                    c.drawRect(cx+r*.025f, cy-r*.22f, cx+r*.11f, cy+r*.22f, p);
                }
            } else {
                c.drawCircle(cx, cy, r * .62f, p);
                p.setStyle(Paint.Style.FILL);
                Path diamond = new Path(); diamond.moveTo(cx, cy-r*.55f); diamond.lineTo(cx+r*.37f, cy);
                diamond.lineTo(cx, cy+r*.55f); diamond.lineTo(cx-r*.37f, cy); diamond.close();
                c.drawPath(diamond, p);
                p.setColor(BLUE); p.setStrokeWidth(dp(1.8f)); p.setStyle(Paint.Style.STROKE);
                c.drawLine(cx, cy-r*.35f, cx, cy+r*.35f, p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        private void drawSensorWarning(Canvas c, float w, float h) {
            String t = "ДАТЧИК НЕ ОБНАРУЖЕН";
            p.setColor(0xCC173B59); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(12));
            c.drawText(t, w * .5f, h - dp(26), p);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = e.getX(); downY = e.getY(); touchHandled = true; return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP && touchHandled) {
                float w = getWidth(), h = getHeight();
                float r = Math.max(dp(25), Math.min(dp(36), Math.min(w, h) * .055f));
                float cx = w - r - dp(34);
                float unitR = Math.max(dp(22), Math.min(dp(30), Math.min(w, h) * .047f));
                float ux = w - unitR - dp(40), uy = dp(42) + unitR * .3f;
                if (distance(downX, downY, ux, uy) < unitR * 1.8f) {
                    percent = !percent;
                } else {
                    boolean portrait = h >= w;
                    float gap = r * 2.65f;
                    float firstY = portrait ? h * .67f : h * .5f - gap;
                    if (distance(downX, downY, cx, firstY) < r * 1.7f) showSettings();
                    else if (distance(downX, downY, cx, firstY + gap) < r * 1.7f) toggleHold();
                    else if (distance(downX, downY, cx, firstY + gap * 2f) < r * 1.7f) toggleAxis();
                }
                invalidate(); touchHandled = false; return true;
            }
            return true;
        }

        private float distance(float x1, float y1, float x2, float y2) {
            float dx = x1 - x2, dy = y1 - y2; return (float)Math.sqrt(dx*dx + dy*dy);
        }
    }
}
