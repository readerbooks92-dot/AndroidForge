package ru.uglomer.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
    private static final String PREFS = "uglomer_settings";
    private static final int BLUE = Color.rgb(7, 133, 233);
    private static final int RED = Color.rgb(238, 24, 18);
    private SensorManager sensorManager;
    private Sensor sensor;
    private AngleView angleView;
    private SharedPreferences prefs;

    private float gx, gy, gz = SensorManager.GRAVITY_EARTH;
    private float rawAngle = 0f;
    private float smoothedAngle = 0f;
    private long lastSensorTimestamp = 0L;
    private boolean angleInitialized = false;
    private boolean vectorInitialized = false;
    private boolean displayAngleInitialized = false;
    private float filteredGx, filteredGy, filteredGz = SensorManager.GRAVITY_EARTH;
    private float displayAngle = 0f;
    private float calibration = 0f;
    private float heldAngle = 0f;
    private float angle = 0f;
    private boolean hasSensor = false;
    private boolean held = false;
    private boolean percent = false;
    private final int precision = 1;
    private boolean changeMode = false;
    // Two touch snapshots; the third tap starts a new pair.
    private boolean hasFixation1 = false, hasFixation2 = false;
    private float fixation1 = 0f, fixation2 = 0f;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BLUE);
        getWindow().setNavigationBarColor(BLUE);
        applyImmersiveMode();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        // Display is intentionally limited to tenths of a degree; this is display
        // resolution, not a claim about the sensor's absolute accuracy.
        calibration = prefs.getFloat("calibration", 0f);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (sensor == null) sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        angleView = new AngleView(this);
        setContentView(angleView);
        if (sensor == null) {
            Toast.makeText(this, "На устройстве не найден датчик ускорения", Toast.LENGTH_LONG).show();
        }
    }

    private void applyImmersiveMode() {
        final int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override protected void onResume() {
        super.onResume();
        // Start each foreground session with a fresh sensor filter state.
        lastSensorTimestamp = 0L;
        vectorInitialized = false;
        angleInitialized = false;
        if (sensor != null) sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.values == null || event.values.length < 3) return;

        float dt = lastSensorTimestamp == 0L ? 0.02f
                : (event.timestamp - lastSensorTimestamp) * 1.0e-9f;
        if (dt <= 0f || dt > 0.25f) dt = 0.02f;

        // Filter the gravity vector itself, not only the final angle. A time-based
        // low-pass behaves consistently across different sensor sampling rates.
        // The gravity sensor is already fused by Android; the accelerometer fallback
        // needs stronger smoothing because it also sees linear hand movement.
        boolean gravitySensor = event.sensor.getType() == Sensor.TYPE_GRAVITY;
        float vectorTimeConstant = gravitySensor ? 0.16f : 0.42f;
        float vectorRetention = (float) Math.exp(-dt / vectorTimeConstant);
        if (!vectorInitialized) {
            filteredGx = event.values[0];
            filteredGy = event.values[1];
            filteredGz = event.values[2];
            vectorInitialized = true;
        } else {
            float inputWeight = 1f - vectorRetention;
            filteredGx = vectorRetention * filteredGx + inputWeight * event.values[0];
            filteredGy = vectorRetention * filteredGy + inputWeight * event.values[1];
            filteredGz = vectorRetention * filteredGz + inputWeight * event.values[2];
        }
        gx = filteredGx;
        gy = filteredGy;
        gz = filteredGz;

        // Convert device coordinates to the fixed portrait screen coordinates.
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        float screenX, screenY;
        switch (rotation) {
            case android.view.Surface.ROTATION_90:
                screenX = gy; screenY = -gx; break;
            case android.view.Surface.ROTATION_180:
                screenX = -gx; screenY = -gy; break;
            case android.view.Surface.ROTATION_270:
                screenX = -gy; screenY = gx; break;
            case android.view.Surface.ROTATION_0:
            default:
                screenX = gx; screenY = gy; break;
        }

        // The inclinometer measures one fixed screen plane. The former X/Y axis
        // selector has been removed to avoid accidental changes of measurement plane.
        float component = screenX;
        float targetAngle = normalize((float) Math.toDegrees(
                Math.atan2(-component, gz)));

        // Smooth the angle itself using the shortest path around the -180/180 boundary.
        // This avoids both visible jitter and a false jump when the reading wraps.
        if (!angleInitialized) {
            smoothedAngle = targetAngle;
            angleInitialized = true;
        } else {
            float dt = (event.timestamp - lastSensorTimestamp) * 1.0e-9f;
            if (dt <= 0f || dt > 0.25f) dt = 0.02f;
            final float timeConstant = gravitySensor ? 0.12f : 0.20f;
            float alpha = 1f - (float) Math.exp(-dt / timeConstant);
            float difference = normalize(targetAngle - smoothedAngle);
            // Suppress tiny sensor noise before it reaches the display quantizer.
            if (Math.abs(difference) < 0.035f) difference = 0f;
            smoothedAngle = normalize(smoothedAngle + alpha * difference);
        }
        lastSensorTimestamp = event.timestamp;
        rawAngle = smoothedAngle;
        angle = held ? heldAngle : stabilizeDisplayAngle(normalize(rawAngle - calibration));
        hasSensor = true;
        if (angleView != null) angleView.postInvalidateOnAnimation();
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private static float normalize(float value) {
        while (value > 180f) value -= 360f;
        while (value < -180f) value += 360f;
        return value;
    }

    /**
     * One-decimal display with a small Schmitt deadband. Without hysteresis, a
     * stationary sensor hovering around a rounding boundary makes the last digit
     * alternate continuously. The 0.02-degree hysteresis is a stability measure,
     * not a statement of measurement accuracy.
     */
    private float stabilizeDisplayAngle(float value) {
        final float step = 0.1f;
        final float boundaryHysteresis = 0.02f;
        if (!displayAngleInitialized) {
            displayAngle = normalize(Math.round(value / step) * step);
            displayAngleInitialized = true;
            return displayAngle;
        }

        float difference = normalize(value - displayAngle);
        float boundary = step * 0.5f + boundaryHysteresis;
        if (difference > boundary) {
            int steps = Math.max(1, (int) Math.floor((difference - boundary) / step) + 1);
            displayAngle = normalize(displayAngle + steps * step);
        } else if (difference < -boundary) {
            int steps = Math.max(1, (int) Math.floor((-difference - boundary) / step) + 1);
            displayAngle = normalize(displayAngle - steps * step);
        }
        return displayAngle;
    }

    private String format(float value, int digits) {
        float epsilon = (float) (0.5 * Math.pow(10, -digits));
        if (Math.abs(value) < epsilon) value = 0f;
        return String.format(Locale.getDefault(), "% ." + digits + "f", value).trim().replace('.', ',').replace('-', '−');
    }

    private String readingText() {
        float a = angle;
        if (percent) return format((float) Math.tan(Math.toRadians(a)) * 100f, precision) + "%";
        return format(a, precision) + "°";
    }

    private void saveSettings() {
        prefs.edit().putFloat("calibration", calibration).apply();
    }

    private void toggleHold() {
        if (!held) {
            heldAngle = angle;
            held = true;
        } else held = false;
        angle = held ? heldAngle : stabilizeDisplayAngle(normalize(rawAngle - calibration));
        angleView.invalidate();
    }

    private void toggleChangeMode() {
        changeMode = !changeMode;
        // Entering or leaving the adjustment mode always starts from a clean pair.
        hasFixation1 = false;
        hasFixation2 = false;
        fixation1 = 0f;
        fixation2 = 0f;
        angleView.invalidate();
    }

    private void showSettings() {
        final String[] items = new String[] {
                "Точность отображения: 0,1°",
                "Принять текущее положение за 0°",
                "Сбросить калибровку",
                "О приложении"
        };
        new AlertDialog.Builder(this)
                .setTitle("Настройки угломера")
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            Toast.makeText(this, "Показания отображаются с шагом 0,1°; это не гарантирует абсолютную точность 0,1°", Toast.LENGTH_LONG).show();
                            break;
                        case 1:
                            calibration = rawAngle;
                            held = false;
                            displayAngle = 0f;
                            displayAngleInitialized = true;
                            angle = 0f;
                            Toast.makeText(this, "Текущее положение принято за 0°", Toast.LENGTH_SHORT).show();
                            break;
                        case 2:
                            calibration = 0f;
                            held = false;
                            displayAngleInitialized = false;
                            angle = stabilizeDisplayAngle(rawAngle);
                            Toast.makeText(this, "Калибровка сброшена", Toast.LENGTH_SHORT).show();
                            break;
                        case 3:
                            new AlertDialog.Builder(this).setTitle("Угломер")
                                    .setMessage("Автономный строительный угломер. Угол рассчитывается по датчику ускорения/гравитации. Шаг индикации — 0,1°, но это не означает абсолютную погрешность 0,1°. Реальная точность зависит от калибровки, температуры, положения телефона и конкретного экземпляра датчика. Для точных работ сравните показания с поверенным уровнем.")
                                    .setPositiveButton("ОК", null).show();
                            return;
                    }
                    saveSettings();
                    angleView.invalidate();
                    showSettings();
                })
                .setNegativeButton("Готово", null)
                .show();
    }

    private class AngleView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float density;
        private float downX, downY;
        private boolean touchHandled;

        AngleView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            // Keep Android hardware acceleration enabled for smooth 60 Hz redraws.
            setFocusable(true);
        }

        private float dp(float v) { return v * density; }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            float liveAngle = angle;
            canvas.drawColor(Color.WHITE);

            if (hasFixation1) {
                // The first captured angle remains fixed. Until the second tap, the other
                // divider follows the live sensor; after the second tap both dividers freeze.
                float secondAngle = hasFixation2 ? fixation2 : liveAngle;
                drawDualField(canvas, w, h, fixation1, secondAngle);
                drawDualReadings(canvas, w, h, fixation1, secondAngle);
            } else {
                drawSingleField(canvas, w, h, liveAngle);
                drawSingleReading(canvas, w, h, liveAngle);
            }

            drawCrosshairAndMarkers(canvas, w, h);
            drawCaptureStateIcon(canvas);
            drawUnitButton(canvas, w, h);
            drawActions(canvas, w, h);
            if (!hasSensor) drawSensorWarning(canvas, w, h);
        }

        /** Original two-colour live view: blue on the positive side, white on the negative side. */
        private void drawSingleField(Canvas c, float w, float h, float angleDeg) {
            float extent = (float) Math.hypot(w, h) * 2.2f;
            Path blueSide = halfPlanePath(w * .5f, h * .5f, angleDeg, true, extent);
            p.setStyle(Paint.Style.FILL);
            p.setColor(BLUE);
            c.drawPath(blueSide, p);
            drawBoundary(c, w, h, angleDeg, 0xFFEAF5FE);
        }

        /**
         * Two captured planes create the three-colour reference graphic:
         * equal half-plane signs => blue (positive/positive) or white (negative/negative);
         * opposite signs => red. This is the same four-sector geometry as the reference image.
         */
        private void drawDualField(Canvas c, float w, float h, float first, float second) {
            float cx = w * .5f, cy = h * .5f;
            float extent = (float) Math.hypot(w, h) * 2.2f;
            Path firstPos = halfPlanePath(cx, cy, first, true, extent);
            Path firstNeg = halfPlanePath(cx, cy, first, false, extent);
            Path secondPos = halfPlanePath(cx, cy, second, true, extent);
            Path secondNeg = halfPlanePath(cx, cy, second, false, extent);

            // Red occupies the two sectors where the two signed plane tests disagree.
            p.setStyle(Paint.Style.FILL);
            p.setColor(RED);
            c.save(); c.clipPath(firstPos); c.clipPath(secondNeg);
            c.drawColor(RED); c.restore();
            c.save(); c.clipPath(firstNeg); c.clipPath(secondPos);
            c.drawColor(RED); c.restore();

            // The remaining positive/positive sector is blue; negative/negative stays white.
            c.save(); c.clipPath(firstPos); c.clipPath(secondPos);
            c.drawColor(BLUE); c.restore();

            drawBoundary(c, w, h, first, 0xBFFFFFFF);
            drawBoundary(c, w, h, second, 0xBFFFFFFF);
        }

        private Path halfPlanePath(float cx, float cy, float angleDeg, boolean positive, float extent) {
            double a = Math.toRadians(angleDeg);
            float nx = (float) Math.cos(a), ny = (float) Math.sin(a);
            float tx = -ny, ty = nx;
            float sign = positive ? 1f : -1f;
            Path out = new Path();
            out.moveTo(cx - tx * extent, cy - ty * extent);
            out.lineTo(cx + tx * extent, cy + ty * extent);
            out.lineTo(cx + tx * extent + nx * extent * sign, cy + ty * extent + ny * extent * sign);
            out.lineTo(cx - tx * extent + nx * extent * sign, cy - ty * extent + ny * extent * sign);
            out.close();
            return out;
        }

        private void drawBoundary(Canvas c, float w, float h, float angleDeg, int color) {
            double a = Math.toRadians(angleDeg);
            float nx = (float) Math.cos(a), ny = (float) Math.sin(a);
            float tx = -ny, ty = nx;
            float extent = (float) Math.hypot(w, h) * 2.2f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(dp(1.25f));
            p.setColor(color);
            c.drawLine(w * .5f - tx * extent, h * .5f - ty * extent,
                    w * .5f + tx * extent, h * .5f + ty * extent, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawCrosshairAndMarkers(Canvas c, float w, float h) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setStrokeWidth(dp(2.2f));
            p.setColor(Color.WHITE); p.setAlpha(225);
            c.drawLine(w * .5f, 0, w * .5f, h * .066f, p);
            c.drawLine(0, h * .5f, w * .143f, h * .5f, p);
            p.setColor(BLUE); p.setAlpha(210);
            c.drawLine(w * .5f, h * .934f, w * .5f, h, p);
            c.drawLine(w * .857f, h * .5f, w, h * .5f, p);
            p.setAlpha(255);
            p.setStrokeWidth(dp(2f));
            c.drawLine(w * .5f, h * .468f, w * .5f, h * .532f, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawSingleReading(Canvas c, float w, float h, float angleDeg) {
            String value = angleText(angleDeg);
            float size = readingTextSize(w, h);
            float cx = w * .5f, cy = h * .5f;
            double a = Math.toRadians(angleDeg);
            float tx = (float) -Math.sin(a), ty = (float) Math.cos(a);
            float offset = Math.min(w, h) * .235f;
            float rot = readableRotation(angleDeg + 90f);
            drawAdaptiveTextSingle(c, w, h, value, cx + tx * offset, cy + ty * offset, rot, size, angleDeg);
        }

        private void drawDualReadings(Canvas c, float w, float h, float first, float second) {
            float size = readingTextSize(w, h);
            float cx = w * .5f, cy = h * .5f;
            float offset = Math.min(w, h) * .225f;
            double a1 = Math.toRadians(first), a2 = Math.toRadians(second);
            float t1x = (float) -Math.sin(a1), t1y = (float) Math.cos(a1);
            float t2x = (float) -Math.sin(a2), t2y = (float) Math.cos(a2);

            // Put the two values on opposite sides of the crosshair, aligned with their own divider.
            drawAdaptiveTextDual(c, w, h, angleText(first),
                    cx - t1x * offset, cy - t1y * offset, readableRotation(first + 90f), size, first, second);
            drawAdaptiveTextDual(c, w, h, angleText(second),
                    cx + t2x * offset, cy + t2y * offset, readableRotation(second + 90f), size, first, second);
        }

        private float readingTextSize(float w, float h) {
            return Math.max(dp(40), Math.min(dp(68), Math.min(w, h) * .105f));
        }

        private float readableRotation(float degrees) {
            // Text follows the measuring line, but is always kept in the readable
            // half-turn. Use a half-open interval so the exact 90-degree boundary
            // cannot alternate between two opposite text orientations.
            while (degrees >= 90f) degrees -= 180f;
            while (degrees < -90f) degrees += 180f;
            return degrees;
        }

        private String angleText(float value) {
            if (percent) return format((float) Math.tan(Math.toRadians(value)) * 100f, 1) + "%";
            return format(value, 1) + "°";
        }

        /** Text is clipped by the very same animated regions as the background. */
        private void drawAdaptiveTextSingle(Canvas c, float w, float h, String text,
                                            float x, float y, float rotation, float textSize, float angleDeg) {
            float extent = (float) Math.hypot(w, h) * 2.2f;
            Path blueSide = halfPlanePath(w * .5f, h * .5f, angleDeg, true, extent);
            Path whiteSide = halfPlanePath(w * .5f, h * .5f, angleDeg, false, extent);
            drawTextInClip(c, text, x, y, rotation, textSize, Color.WHITE, blueSide);
            drawTextInClip(c, text, x, y, rotation, textSize, BLUE, whiteSide);
        }

        private void drawAdaptiveTextDual(Canvas c, float w, float h, String text,
                                          float x, float y, float rotation, float textSize,
                                          float first, float second) {
            float cx = w * .5f, cy = h * .5f;
            float extent = (float) Math.hypot(w, h) * 2.2f;
            Path firstPos = halfPlanePath(cx, cy, first, true, extent);
            Path firstNeg = halfPlanePath(cx, cy, first, false, extent);
            Path secondPos = halfPlanePath(cx, cy, second, true, extent);
            Path secondNeg = halfPlanePath(cx, cy, second, false, extent);

            // Blue area: white digits.
            drawTextInClip(c, text, x, y, rotation, textSize, Color.WHITE, firstPos, secondPos);
            // White area: blue digits.
            drawTextInClip(c, text, x, y, rotation, textSize, BLUE, firstNeg, secondNeg);
            // Both red sectors: white digits.
            drawTextInClip(c, text, x, y, rotation, textSize, Color.WHITE, firstPos, secondNeg);
            drawTextInClip(c, text, x, y, rotation, textSize, Color.WHITE, firstNeg, secondPos);
        }

        private void drawTextInClip(Canvas c, String text, float x, float y, float rotation,
                                    float textSize, int color, Path... clips) {
            c.save();
            for (Path clip : clips) c.clipPath(clip);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setAlpha(255);
            p.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
            p.setTextSize(textSize);
            p.setTextAlign(Paint.Align.CENTER);
            p.clearShadowLayer();
            c.save();
            c.translate(x, y);
            c.rotate(rotation);
            float baseline = -(p.ascent() + p.descent()) * .5f;
            c.drawText(text, 0f, baseline, p);
            c.restore();
            c.restore();
        }

        /**
         * Capture state indicator in the upper-left corner:
         * first tap = protractor icon; second tap = padlock icon; unlocked = no icon.
         */
        private void drawCaptureStateIcon(Canvas c) {
            if (!changeMode || !hasFixation1) return;
            float cx = dp(47f);
            float cy = dp(47f);
            float s = dp(27f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(dp(2.5f));
            p.setColor(Color.WHITE);
            p.setAlpha(255);
            p.setShadowLayer(dp(1.5f), 0f, dp(1f), 0x88000000);

            if (!hasFixation2) {
                // Simple recognizable angle-measurer / protractor pictogram.
                RectF arc = new RectF(cx - s * .68f, cy - s * .68f,
                        cx + s * .68f, cy + s * .68f);
                c.drawArc(arc, 180f, 180f, false, p);
                c.drawLine(cx - s * .78f, cy + s * .12f,
                        cx + s * .78f, cy + s * .12f, p);
                c.drawLine(cx, cy + s * .12f, cx + s * .43f, cy - s * .50f, p);
                for (int i = 0; i <= 6; i++) {
                    double a = Math.PI + Math.PI * i / 6.0;
                    float x1 = cx + (float)Math.cos(a) * s * .55f;
                    float y1 = cy + (float)Math.sin(a) * s * .55f;
                    float x2 = cx + (float)Math.cos(a) * s * .68f;
                    float y2 = cy + (float)Math.sin(a) * s * .68f;
                    c.drawLine(x1, y1, x2, y2, p);
                }
            } else {
                // Padlock: curved shackle plus a rounded rectangular body and keyhole.
                RectF shackle = new RectF(cx - s * .38f, cy - s * .72f,
                        cx + s * .38f, cy + s * .18f);
                c.drawArc(shackle, 180f, 180f, false, p);
                RectF body = new RectF(cx - s * .58f, cy - s * .13f,
                        cx + s * .58f, cy + s * .78f);
                c.drawRoundRect(body, dp(3f), dp(3f), p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy + s * .20f, dp(2.2f), p);
                p.setStyle(Paint.Style.STROKE);
                c.drawLine(cx, cy + s * .23f, cx, cy + s * .40f, p);
            }
            p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);
        }

        private void drawUnitButton(Canvas c, float w, float h) {
            float r = Math.max(dp(22), Math.min(dp(30), Math.min(w, h) * .047f));
            float cx = w - r - dp(40), cy = dp(42) + r * .3f;
            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE);
            c.drawCircle(cx, cy, r, p);
            c.save(); c.clipRect(cx - r - 1, cy, cx + r + 1, cy + r + 1);
            p.setColor(BLUE); c.drawCircle(cx, cy, r - dp(1), p); c.restore();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(BLUE);
            c.drawCircle(cx, cy, r, p);
            if (percent) {
                p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(r * 1.0f); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                c.drawText("%", cx, cy + r * .35f, p);
            }
        }

        private void drawActions(Canvas c, float w, float h) {
            float r = Math.max(dp(25), Math.min(dp(36), Math.min(w, h) * .055f));
            float cx = w - r - dp(34);
            boolean portrait = h >= w;
            float gap = r * 2.65f;
            float firstY = portrait ? h * .67f : h * .5f - gap;
            float y1 = firstY, y2 = firstY + gap, y3 = firstY + gap * 2f;
            drawActionCircle(c, cx, y1, r, 0);
            drawActionCircle(c, cx, y2, r, held ? 1 : 2);
            drawActionCircle(c, cx, y3, r, 3, changeMode);
        }

        private void drawActionCircle(Canvas c, float cx, float cy, float r, int icon) {
            drawActionCircle(c, cx, cy, r, icon, false);
        }

        private void drawActionCircle(Canvas c, float cx, float cy, float r, int icon, boolean active) {
            boolean selectedModeButton = icon == 3 && active;
            p.setStyle(Paint.Style.FILL); p.setColor(selectedModeButton ? Color.WHITE : BLUE);
            p.setShadowLayer(dp(3), 0, dp(2), 0x22000000);
            c.drawCircle(cx, cy, r, p); p.clearShadowLayer();
            int glyphColor = selectedModeButton ? BLUE : Color.WHITE;
            p.setColor(glyphColor); p.setStrokeWidth(dp(2.5f)); p.setStyle(Paint.Style.STROKE);
            if (icon == 0) {
                c.drawCircle(cx, cy, r * .43f, p); c.drawCircle(cx, cy, r * .19f, p);
                for (int i = 0; i < 8; i++) {
                    double t = i * Math.PI / 4;
                    c.drawLine(cx + (float)Math.cos(t)*r*.5f, cy + (float)Math.sin(t)*r*.5f,
                            cx + (float)Math.cos(t)*r*.68f, cy + (float)Math.sin(t)*r*.68f, p);
                }
            } else if (icon == 1 || icon == 2) {
                c.drawCircle(cx, cy, r * .58f, p); c.drawCircle(cx, cy, r * .32f, p);
                for (int i = 0; i < 4; i++) {
                    double t = i * Math.PI / 2;
                    c.drawLine(cx + (float)Math.cos(t)*r*.72f, cy + (float)Math.sin(t)*r*.72f,
                            cx + (float)Math.cos(t)*r*.9f, cy + (float)Math.sin(t)*r*.9f, p);
                }
                if (icon == 1) {
                    p.setStyle(Paint.Style.FILL);
                    c.drawRect(cx-r*.11f, cy-r*.22f, cx-r*.025f, cy+r*.22f, p);
                    c.drawRect(cx+r*.025f, cy-r*.22f, cx+r*.11f, cy+r*.22f, p);
                }
            } else {
                // Adjustment-mode glyph: a tilted measuring edge with a pencil tip.
                p.setStrokeCap(Paint.Cap.ROUND);
                c.drawLine(cx-r*.30f, cy+r*.30f, cx+r*.24f, cy-r*.24f, p);
                c.drawLine(cx-r*.18f, cy+r*.42f, cx+r*.36f, cy-r*.12f, p);
                Path tip = new Path();
                tip.moveTo(cx+r*.24f, cy-r*.24f);
                tip.lineTo(cx+r*.42f, cy-r*.42f);
                tip.lineTo(cx+r*.36f, cy-r*.12f);
                tip.close();
                p.setStyle(Paint.Style.FILL);
                c.drawPath(tip, p);
                p.setStyle(Paint.Style.STROKE);
                c.drawLine(cx-r*.42f, cy+r*.42f, cx-r*.08f, cy+r*.42f, p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        private void drawSensorWarning(Canvas c, float w, float h) {
            String t = "ДАТЧИК НЕ ОБНАРУЖЕН";
            p.setColor(0xCC173B59); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(12));
            c.drawText(t, w * .5f, h - dp(26), p);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = e.getX(); downY = e.getY(); touchHandled = true; return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP && touchHandled) {
                float w = getWidth(), h = getHeight();
                float r = Math.max(dp(25), Math.min(dp(36), Math.min(w, h) * .055f));
                float cx = w - r - dp(34);
                float unitR = Math.max(dp(22), Math.min(dp(30), Math.min(w, h) * .047f));
                float ux = w - unitR - dp(40), uy = dp(42) + unitR * .3f;
                boolean isTap = distance(downX, downY, e.getX(), e.getY()) < dp(24);
                if (isTap) {
                    if (distance(downX, downY, ux, uy) < unitR * 1.8f) {
                        percent = !percent;
                    } else {
                        boolean portrait = h >= w;
                        float gap = r * 2.65f;
                        float firstY = portrait ? h * .67f : h * .5f - gap;
                        if (distance(downX, downY, cx, firstY) < r * 1.7f) showSettings();
                        else if (distance(downX, downY, cx, firstY + gap) < r * 1.7f) toggleHold();
                        else if (distance(downX, downY, cx, firstY + gap * 2f) < r * 1.7f) toggleChangeMode();
                        else if (changeMode) captureFixation();
                    }
                }
                invalidate(); touchHandled = false; return true;
            }
            if (e.getAction() == MotionEvent.ACTION_CANCEL) touchHandled = false;
            return true;
        }

        private void captureFixation() {
            // Background taps are measurement captures only after the mode button
            // has explicitly enabled adjustment mode.
            if (!changeMode) return;

            // A third background tap after the lock clears both snapshots,
            // exits adjustment mode and is the only mode action with a toast.
            if (hasFixation2) {
                hasFixation1 = false;
                hasFixation2 = false;
                fixation1 = 0f;
                fixation2 = 0f;
                changeMode = false;
                invalidate();
                Toast.makeText(MainActivity.this, "Разблокировано", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!hasSensor) return;

            float snapshot = angle;
            if (!hasFixation1) {
                // First tap freezes the first line and shows the protractor icon.
                fixation1 = snapshot;
                hasFixation1 = true;
                hasFixation2 = false;
            } else {
                // Second tap freezes the second line; protractor is replaced by a padlock.
                fixation2 = snapshot;
                hasFixation2 = true;
            }
            invalidate();
        }

        private float distance(float x1, float y1, float x2, float y2) {
            float dx = x1 - x2, dy = y1 - y2; return (float)Math.sqrt(dx*dx + dy*dy);
        }
    }
}
