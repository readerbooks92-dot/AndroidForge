#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID_BUILD_TOOLS="${ANDROID_BUILD_TOOLS:-}"
if [[ -z "$ANDROID_BUILD_TOOLS" ]]; then
  SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/opt/android-sdk}}"
  while IFS= read -r candidate; do
    if [[ -x "$candidate/apksigner" && -x "$candidate/zipalign" ]]; then
      ANDROID_BUILD_TOOLS="$candidate"
      break
    fi
  done < <(find "$SDK_ROOT/build-tools" -mindepth 2 -maxdepth 2 -type f -name apksigner -printf '%h\n' 2>/dev/null | sort -Vr)
fi
if [[ -z "$ANDROID_BUILD_TOOLS" || ! -x "$ANDROID_BUILD_TOOLS/apksigner" || ! -x "$ANDROID_BUILD_TOOLS/zipalign" ]]; then
  echo "ERROR: Android Build Tools with apksigner and zipalign were not found" >&2
  exit 2
fi

for cmd in keytool zip python3 curl java; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "ERROR: required command not found: $cmd" >&2; exit 2; }
done

APKEDITOR_VERSION="1.4.9"
APKEDITOR_URL="https://github.com/REAndroid/APKEditor/releases/download/V${APKEDITOR_VERSION}/APKEditor-${APKEDITOR_VERSION}.jar"
APKEDITOR_JAR="$ROOT/tools/APKEditor-${APKEDITOR_VERSION}.jar"
mkdir -p "$ROOT/tools" "$ROOT/build/merge-input" "$ROOT/build/prepared"
if [[ ! -s "$APKEDITOR_JAR" ]]; then
  echo "Downloading official APKEditor ${APKEDITOR_VERSION}..."
  curl --fail --location --retry 4 --retry-delay 2 "$APKEDITOR_URL" --output "$APKEDITOR_JAR"
fi

PREP="$ROOT/build/prepared"
MERGE="$ROOT/build/merge-input"
OUT="$ROOT/build/outputs/apk/debug"
mkdir -p "$OUT"
rm -rf "$MERGE" "$PREP" "$OUT"
mkdir -p "$MERGE" "$PREP" "$OUT"

# Prepare config splits without the original Google Play signing metadata.
for split in split_config.arm64_v8a split_config.ru split_config.xxhdpi; do
  python3 "$ROOT/scripts/clean_split.py" \
    "$ROOT/input/$split.apk.source" "$MERGE/$split.apk"
done
cp "$ROOT/build/base-unsigned.apk" "$MERGE/base.apk"

# Merge base + ABI + language + density splits into one standalone APK.
java -Xmx4g -jar "$APKEDITOR_JAR" m \
  -i "$MERGE" \
  -o "$ROOT/build/universal-unsigned.apk" \
  -clean-meta -validate-modules -f

if [[ ! -s "$ROOT/build/universal-unsigned.apk" ]]; then
  echo "ERROR: APKEditor did not create the merged standalone APK" >&2
  exit 3
fi

# Basic structural checks: the result must contain merged resources and ARM64 libs.
python3 - "$ROOT/build/universal-unsigned.apk" <<'PY'
import sys, zipfile
p = sys.argv[1]
with zipfile.ZipFile(p) as z:
    names = set(z.namelist())
    if 'AndroidManifest.xml' not in names or 'resources.arsc' not in names:
        raise SystemExit('ERROR: merged APK is missing manifest or resources.arsc')
    if not any(n.startswith('lib/arm64-v8a/') and n.endswith('.so') for n in names):
        raise SystemExit('ERROR: merged APK is missing ARM64 native libraries')
    print(f'Universal APK structure OK: {len(names)} entries')
PY

# A modified APK cannot keep the developer's original signature.
STORE_PASS="$(python3 -c 'import secrets; print(secrets.token_hex(16))')"
KEYSTORE="$ROOT/build/local-signing.jks"
keytool -genkeypair -v \
  -keystore "$KEYSTORE" \
  -storepass "$STORE_PASS" \
  -keypass "$STORE_PASS" \
  -alias stroitelny-ugolomer-local \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=Stroitelny Ugolomer Local Modified Build, O=Personal Use" \
  -noprompt >/dev/null 2>&1

UNSIGNED="$ROOT/build/universal-unsigned.apk"
ALIGNED="$ROOT/build/universal-aligned.apk"
FINAL="$OUT/Stroitelny-ugolomer-debug.apk"
"$ANDROID_BUILD_TOOLS/zipalign" -f -p 4 "$UNSIGNED" "$ALIGNED"
"$ANDROID_BUILD_TOOLS/apksigner" sign \
  --ks "$KEYSTORE" \
  --ks-key-alias stroitelny-ugolomer-local \
  --ks-pass "pass:$STORE_PASS" \
  --key-pass "pass:$STORE_PASS" \
  --out "$FINAL" "$ALIGNED"
"$ANDROID_BUILD_TOOLS/apksigner" verify --verbose "$FINAL"

# Confirm there is exactly one installable APK in AndroidForge's output directory.
COUNT="$(find "$OUT" -maxdepth 1 -type f -name '*.apk' | wc -l | tr -d ' ')"
[[ "$COUNT" == "1" ]] || { echo "ERROR: expected exactly one APK, found $COUNT" >&2; exit 4; }

cat > "$ROOT/build/INSTALL.txt" <<'TXT'
Строительный угломер 8.7 — единый standalone APK.

Устанавливается одним файлом: Stroitelny-ugolomer-debug.apk.

Важно:
- Сборка содержит ABI arm64-v8a, так как в исходном комплекте был только этот ABI.
- APK подписан новым локальным ключом, поэтому не обновит оригинал Google Play поверх него.
- Перед установкой удалите оригинальное приложение. Это может удалить его локальные настройки/калибровки.
- Патч отключает один найденный запрос межстраничной рекламы Yandex; другие рекламные элементы этим не исключаются.
TXT
cp "$ROOT/build/decoded/PATCH_REPORT.txt" "$ROOT/build/PATCH_REPORT.txt"
(cd "$OUT" && zip -q -9 "$ROOT/build/Stroitelny_ugolomer_8.7_single_APK.zip" "$(basename "$FINAL")")
printf '\nCreated ONE standalone APK: %s\n' "$FINAL"
printf 'ZIP containing one APK: %s\n' "$ROOT/build/Stroitelny_ugolomer_8.7_single_APK.zip"
