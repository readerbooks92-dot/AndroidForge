#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.7 не найден. Установите Gradle 8.7 и JDK 17, затем повторите запуск."
  exit 1
fi
gradle --version
gradle assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
